let n = prompt("Enter the size of array");
let Arr = new Array();
for(var i=0;i<n;i++)
{
    Arr[i] = prompt("Enter the string");
}

for(i=0;i<n;i++)
{
    for(var j=0;j<Arr.length;j++)
    {
        if(Arr[i][j]=='a')
        {
            console.log(Arr[i]);
            break;
        }
    }
}