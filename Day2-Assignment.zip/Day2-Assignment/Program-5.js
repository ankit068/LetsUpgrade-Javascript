let n = prompt("Enter the size of array");
let Arr = new Array();
for(var i=0;i<n;i++)
{
    Arr[i] = prompt("Enter the Array elements");
}

let Arr1 = new Array();
Arr1 = Arr.reverse();

for(i=0;i<n;i++);
{
    console.log(Arr1[i]);
}