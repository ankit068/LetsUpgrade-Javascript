let a = prompt("Enter the String");
let b = prompt("Enter the character");
let p=0;

for(var i=0;i<a.length;i++)
{
    if(b==a[i])
    {
        p++;
        console.log("position of "+b+ " character is at "+ i);
    }
}
if(p==0)
{
    console.log("Character not found in the String!");
}