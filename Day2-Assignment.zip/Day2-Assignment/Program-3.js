let n = prompt("Enter the size of array");
let Arr = new Array();
for(var i=0;i<n;i++)
{
    Arr[i] = prompt("Enter the string");
}

let element = prompt("enter the element to be searched");

var key=Arr.indexOf(element);
if(key==-1)
{
    console.log("Element not found in the Array of String");
}

else
{
    console.log("Element found at position at "+ key);
}