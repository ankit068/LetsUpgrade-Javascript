let minute = prompt("Enter the number of minutes");
console.log("number of seconds in minutes "+ minute*60);